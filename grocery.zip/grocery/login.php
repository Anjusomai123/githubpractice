<?php
// connection with database 
include 'config.php';
// Session
session_start();
if (isset($_POST['submit'])) {
    // Validate and sanitize email
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    // Validate and sanitize password
    $pass = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);

    // Check if email and password are not empty
    if (!empty($email) && !empty($pass)) {
        // Select data
        $select = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
        $select->execute([$email]);
        $row = $select->fetch(PDO::FETCH_ASSOC);

        if ($select->rowCount() > 0) {
            if ($row['password'] === $pass) {
                if ($row['user_type'] == 'admin') {
                    // Admin redirect to admin page
                    $_SESSION['admin_id'] = $row['id'];
                    header('location:admin_page.php');
                } elseif ($row['user_type'] == 'user') {
                    // User direct redirect to home page
                    $_SESSION['user_id'] = $row['id'];
                    header('location:home.php');
                }
            } else {
                $_SESSION['error'] = 'Incorrect email or password!';
            }
        } else {
            $_SESSION['error'] = 'User not found!';
        }
    } else {
        $_SESSION['error'] = 'Please provide both email and password!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login form</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/components.css">
</head>
<body>
    <section class="form-containers">
        <form action="" enctype="multipart/form-data" method="POST">
            <h3>Login now</h3>
            <?php
            if (isset($_SESSION['error'])) {
                echo '
<div class="msg">
 <span>' . $_SESSION['error'] . '</span>
</div>
';
                unset($_SESSION['error']);
            }
            ?>
            <input type="email" name="email" class="box" placeholder="Enter your email" value="<?php echo @$email; ?>">
            <input type="password" name="pass" class="box" placeholder="Enter your password">
            <input type="submit" value="Login" class="btn" name="submit">
            <p>Don't have an account? <a href="register.php">Register now</a></p>
        </form>
    </section>
</body>
</html>
