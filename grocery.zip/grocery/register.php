<?php
// connection with database 
include 'config.php';
if (isset($_POST['submit'])) {
    $status = 1;
    $name = $_POST['name'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    if (empty($name)) {
        $errors['name'] = 'Please enter your name';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $errors['name'] = 'Name should only contain letters and spaces';
        $status = 0;
    } elseif (strlen($name) < 3) {
        $errors['name'] = 'Name should be at least 3 characters long';
        $status = 0;
    }

    $email = $_POST['email'];
    $email = filter_var($email, FILTER_SANITIZE_STRING);
    $pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";
    if (empty($_POST["email"])) {
        $errors['email'] = "Email is required";
        $status = 0;
    } else {
        $email = ($_POST["email"]);
        if (!preg_match($pattern, $email)) {
            $errors['email'] = "Invalid email format";
            $status = 0;
        }
    }

    $pass = $_POST['pass'];
    $pass = filter_var($pass, FILTER_SANITIZE_STRING);
    if (empty($pass)) {
        $errors['pass'] = 'Please enter your password';
        $status = 0;
    } else {
        $uppercase = preg_match('@[A-Z]@', $pass);
        $lowercase = preg_match('@[a-z]@', $pass);
        $number    = preg_match('@[0-9]@', $pass);
        $specialChars = preg_match('@[^\w]@', $pass);

        if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($pass) < 6) {
            $errors['pass'] = "Please ensure your password includes Uppercase & lowercase letter and number with special symbol";
            $status = 0;
        }
    }

    $cpass = $_POST['cpass'];
    $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);
    if (empty($cpass)) {
        $errors['cpass'] = 'Please confirm your password';
        $status = 0;
    } elseif ($pass !== $cpass) {
        $errors['cpass'] = 'Confirm password does not match';
        $status = 0;
    }

    $image = $_FILES['image']['name'];
    $image = filter_var($image, FILTER_SANITIZE_STRING);
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = 'images/' . $image;
    if ($status == 1) {
        $select = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
        $select->execute([$email]);
        if ($select->rowCount() > 0) {
            $errors['email'] = 'User email is already exist!';
        } else {
            $insert = $conn->prepare("INSERT INTO `users`(name, email, password, image) VALUES(?,?,?,?)");
            $insert->execute([$name, $email, $pass, $image]);

            if ($insert) {
                if ($image_size > 2000000) {
                    $errors['image'] = 'Image size is too large!';
                } else {
                    move_uploaded_file($image_tmp_name, $image_folder);
                    // $age="Success";
                    header('location:login.php');
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register form</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/components.css">
</head>

<body>
    <section class="form-container">
        <form action="" enctype="multipart/form-data" method="POST">
            <h3>Register now</h3>

            <input type="text" name="name" class="box" placeholder="Enter your name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>">
            <?php if (isset($errors['name'])) : ?>
                <div class="error-message"><?php echo $errors['name']; ?></div>
            <?php endif; ?>

            <input type="email" name="email" class="box" placeholder="Enter your email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
            <?php if (isset($errors['email'])) : ?>
                <div class="error-message"><?php echo $errors['email']; ?></div>
            <?php endif; ?>

            <input type="password" name="pass" class="box" placeholder="Enter your password">
            <?php if (isset($errors['pass'])) : ?>
                <div class="error-message"><?php echo $errors['pass']; ?></div>
            <?php endif; ?>

            <input type="password" name="cpass" class="box" placeholder="Confirm your password">
            <?php if (isset($errors['cpass'])) : ?>
                <div class="error-message"><?php echo $errors['cpass']; ?></div>
            <?php endif; ?>


            <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png, image/svg, image/jpeg, image/tiff, image/gif, image/eps" value="<?php echo $image; ?>">
            <?php if (isset($errors['image'])) : ?>
                <div class="error-message"><?php echo $errors['image']; ?></div>
            <?php endif; ?>

            <input type="submit" value="Register now" class="btn" name="submit">
            <p>Already have an account? <a href="login.php">Login now</a></p>
        </form>
    </section>
</body>
</html>