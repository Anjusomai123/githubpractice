<?php
@include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
}

$errors = [];

if (isset($_POST['send'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $msg = $_POST['msg'];

    
    // Validate Name
    if (empty($name)) {
        $errors['name'] = 'Please enter your name';
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $errors['name'] = 'Name should only contain letters and spaces';
    } elseif (strlen($name) < 3) {
        $errors['name'] = 'Name should be at least 3 characters long';
    }

    // Validate Email
    if (empty($email)) {
        $errors['email'] = 'Please enter your email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
    }

    // Validate Number
    if (empty($number)) {
        $errors['number'] = 'Please enter your number';
    } elseif (!preg_match("/^[0-9]{10}$/", $number)) {
        $errors['number'] = 'Number should be a 10-digit value';
    }



    // Validate Message
    if (empty($msg)) {
        $errors['msg'] = 'Please enter your message';
    }

    if (count($errors) === 0) {
        $select_message = $conn->prepare("SELECT * FROM `message` WHERE name = ? AND email = ? AND number = ? AND message = ?");
        $select_message->execute([$name, $email, $number, $msg]);

        if ($select_message->rowCount() > 0) {
            $_SESSION['error'] = 'Already sent message!';
        } else {
            $insert_message = $conn->prepare("INSERT INTO `message`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
            $insert_message->execute([$user_id, $name, $email, $number, $msg]);

            $_SESSION['success'] = 'Sent message successfully!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <section class="contact">
        <?php if (isset($_SESSION['success'])) : ?>
            <div class="message success">
                <span><?php echo $_SESSION['success']; ?></span>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])) : ?>
            <div class="message error">
                <span><?php echo $_SESSION['error']; ?></span>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <h1 class="title">get in touch</h1>
        <form action="" method="POST">
            <input type="text" name="name" class="box" placeholder="Enter your name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>">
            <?php if (isset($errors['name'])) : ?>
                <div class="error-message"><?php echo $errors['name']; ?></div>
            <?php endif; ?>

            <input type="email" name="email" class="box" placeholder="Enter your email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
            <?php if (isset($errors['email'])) : ?>
                <div class="error-message"><?php echo $errors['email']; ?></div>
            <?php endif; ?>

            <input type="number" name="number" min="0" class="box" placeholder="Enter your number" value="<?php echo isset($number) ? htmlspecialchars($number) : ''; ?>">
            <?php if (isset($errors['number'])) : ?>
                <div class="error-message"><?php echo $errors['number']; ?></div>
            <?php endif; ?>

            <textarea name="msg" class="box" placeholder="Enter your message" cols="30" rows="10"><?php echo isset($msg) ? htmlspecialchars($msg) : ''; ?></textarea>
            <?php if (isset($errors['msg'])) : ?>
                <div class="error-message"><?php echo $errors['msg']; ?></div>
            <?php endif; ?>

            <input type="submit" value="send message" class="btn" name="send">
        </form>
    </section>

    <?php include 'footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>