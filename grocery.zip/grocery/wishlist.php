<?php
@include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
    exit(); // Add an exit statement after redirecting to prevent further execution
}

if (isset($_POST['add_to_cart'])) {
    $pid = $_POST['pid'];
    $pid = filter_var($pid, FILTER_SANITIZE_STRING);
    $p_name = $_POST['p_name'];
    $p_name = filter_var($p_name, FILTER_SANITIZE_STRING);
    $p_price = $_POST['p_price'];
    $p_price = filter_var($p_price, FILTER_SANITIZE_STRING);
    $p_image = $_POST['p_image'];
    $p_image = filter_var($p_image, FILTER_SANITIZE_STRING);
    $p_qty = $_POST['p_qty'];
    $p_qty = filter_var($p_qty, FILTER_SANITIZE_STRING);

    // Check if the requested quantity is greater than the available quantity
    $check_quantity = $conn->prepare("SELECT quantity FROM `products` WHERE id = ?");
    $check_quantity->execute([$pid]);
    $available_quantity = $check_quantity->fetchColumn();

    if ($available_quantity < $p_qty) {
        $_SESSION['error'] = 'Requested quantity is not available.';
    } else {
        $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE name = ? AND user_id = ?");
        $check_cart_numbers->execute([$p_name, $user_id]);

        if ($check_cart_numbers->rowCount() > 0) {
            $_SESSION['error'] = 'Already added to cart!';
        } else {
            $check_wishlist_numbers = $conn->prepare("SELECT * FROM `wishlist` WHERE name = ? AND user_id = ?");
            $check_wishlist_numbers->execute([$p_name, $user_id]);

            if ($check_wishlist_numbers->rowCount() > 0) {
                $delete_wishlist = $conn->prepare("DELETE FROM `wishlist` WHERE name = ? AND user_id = ?");
                $delete_wishlist->execute([$p_name, $user_id]);
            }

            $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
            $insert_cart->execute([$user_id, $pid, $p_name, $p_price, $p_qty, $p_image]);

            // Update product quantity in the cart
            $update_product_qty = $conn->prepare("UPDATE `products` SET quantity = quantity - ? WHERE id = ?");
            $update_product_qty->execute([$p_qty, $pid]);

            $_SESSION['success'] = 'Added to cart!';
        }
    }
}

if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_wishlist_item = $conn->prepare("DELETE FROM `wishlist` WHERE id = ?");
    $delete_wishlist_item->execute([$delete_id]);
    header('location:wishlist.php');
    exit(); // Add an exit statement after redirecting to prevent further execution
}

if (isset($_GET['delete_all'])) {
    $delete_wishlist_item = $conn->prepare("DELETE FROM `wishlist` WHERE user_id = ?");
    $delete_wishlist_item->execute([$user_id]);
    header('location:wishlist.php');
    exit(); // Add an exit statement after redirecting to prevent further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <section class="wishlist">
        <h1 class="title">Products added</h1>
        <?php
        if (isset($_SESSION['success'])) {
            echo '
         <div class="message success">
             <span>' . $_SESSION['success'] . '</span>
         </div>
         ';
            unset($_SESSION['success']);
        } ?>

        <?php
        if (isset($_SESSION['error'])) {
            echo '
   <div class="message error">
       <span>' . $_SESSION['error'] . '</span>
   </div>
   ';
            unset($_SESSION['error']);
        }
        ?>
        <div class="box-container">
            <?php
            $grand_total = 0;
            $select_wishlist = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
            $select_wishlist->execute([$user_id]);
            if ($select_wishlist->rowCount() > 0) {
                while ($fetch_wishlist = $select_wishlist->fetch(PDO::FETCH_ASSOC)) {
                    $product_id = $fetch_wishlist['pid'];

                    // Retrieve additional product information from the 'products' table
                    $product_info = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
                    $product_info->execute([$product_id]);
                    $product = $product_info->fetch(PDO::FETCH_ASSOC);

                    $available_quantity = $product['quantity'];
                    $category = $product['category'];
                    $mfg_date = $product['mfg_date'];
                    $exp_date = $product['exp_date'];
                    $details = $product['details'];
            ?>
                    <form action="" class="box" method="POST">
                        <a href="wishlist.php?delete=<?= $fetch_wishlist['id']; ?>" class="fas fa-times" onclick="return confirm('Delete this from wishlist?');"></a>
                        <div class="price">Rs.<span><?= $fetch_wishlist['price']; ?></span>/-</div>
                        <a href="view_page.php?pid=<?= $product_id; ?>" class="fas fa-eye"></a>
                        <img src="images/<?= $fetch_wishlist['image']; ?>" alt="" style="width: 225px; height: 200px;">
                        <div class="name">Name: <?= $fetch_wishlist['name']; ?></div>
                        <div class="category">Category: <?= $category; ?></div>
                        <div class="quantity">Available quantity: <?= $available_quantity; ?> Kg</div>
                        <div class="mfg_date">Manufacture date: <?= $mfg_date; ?></div>
                        <div class="exp_date">Expiration date: <?= $exp_date; ?></div>
                        <!-- <div class="details">Details: <?= $details; ?></div> -->

                        <input type="hidden" name="pid" value="<?= $fetch_wishlist['pid']; ?>">
                        <input type="hidden" name="p_name" value="<?= $fetch_wishlist['name']; ?>">
                        <input type="hidden" name="p_price" value="<?= $fetch_wishlist['price']; ?>">
                        <input type="hidden" name="p_image" value="<?= $fetch_wishlist['image']; ?>">
                        <input type="number" min="1" value="1" name="p_qty" class="qty">
                        <input type="submit" value="Add to Wishlist" class="option-btn" name="add_to_wishlist">
                        <input type="submit" value="Add to Cart" class="btn" name="add_to_cart">
                    </form>
            <?php
                    // Calculate the total price
                    $grand_total += $fetch_wishlist['price'];
                }
            } else {
                echo '<p class="empty">Your wishlist is empty</p>';
            }
            ?>
        </div>
        <div class="wishlist-total">
            <p>Grand total: <span>Rs.<?= $grand_total; ?>/-</span></p>
            <a href="shop.php" class="option-btn">Continue Shopping</a>
            <a href="wishlist.php?delete_all" class="delete-btn <?= ($grand_total > 0) ? '' : 'disabled'; ?>">Delete All</a>
        </div>
    </section>
    <?php include 'footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>