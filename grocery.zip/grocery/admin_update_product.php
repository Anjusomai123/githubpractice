<?php
@include 'config.php';
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id)) {
    header('location:login.php');
    exit();
}

if (isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $details = $_POST['details'];
    $quantity = $_POST['quantity'];
    $mfg_date = $_POST['mfg_date'];
    $exp_date = $_POST['exp_date'];

    // Perform input validation and sanitization
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $price = filter_var($price, FILTER_SANITIZE_STRING);
    $category = filter_var($category, FILTER_SANITIZE_STRING);
    $details = filter_var($details, FILTER_SANITIZE_STRING);
    $quantity = filter_var($quantity, FILTER_SANITIZE_NUMBER_INT);
    $mfg_date = filter_var($mfg_date, FILTER_SANITIZE_STRING);
    $exp_date = filter_var($exp_date, FILTER_SANITIZE_STRING);

    // Validate quantity
    if (!is_numeric($quantity) || $quantity <= 0) {
        $_SESSION['error'] = 'Invalid quantity!';
        header('location: admin_products.php');
        exit();
    }

    // Validate manufacturing date and expiration date
    $mfgTimestamp = strtotime($mfg_date);
    $expTimestamp = strtotime($exp_date);
    if ($mfgTimestamp === false || $expTimestamp === false || $mfgTimestamp > $expTimestamp) {
        $_SESSION['error'] = 'Invalid manufacturing date or expiration date!';
        header('location: admin_products.php');
        exit();
    }

    $image = $_FILES['image']['name'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_size = $_FILES['image']['size'];
    $image_folder = 'images/' . $image;
    $old_image = $_POST['old_image'];

    // Check if a new image is uploaded
    if (!empty($image)) {
        // Perform image size validation
        if ($image_size > 2000000) {
            $_SESSION['error'] = 'Image size is too large!';
            header('location: admin_products.php');
            exit();
        }

        // Update the product details and image in the database
        $update_product = $conn->prepare("UPDATE `products` SET name = ?, category = ?, details = ?, price = ?, quantity = ?, mfg_date = ?, exp_date = ?, image = ? WHERE id = ?");
        $update_product->execute([$name, $category, $details, $price, $quantity, $mfg_date, $exp_date, $image, $id]);

        if ($update_product) {
            move_uploaded_file($image_tmp_name, $image_folder);
            @unlink('images/' . $old_image);
        }
    } else {
        // Update the product details without changing the image
        $update_product = $conn->prepare("UPDATE `products` SET name = ?, category = ?, details = ?, price = ?, quantity = ?, mfg_date = ?, exp_date = ? WHERE id = ?");
        $update_product->execute([$name, $category, $details, $price, $quantity, $mfg_date, $exp_date, $id]);
    }

    $_SESSION['success'] = 'Product updated successfully!';
    header('location: admin_products.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Products</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom CSS file link -->
    <link rel="stylesheet" href="css/admin_style.css">
</head>

<body>
    <?php include 'admin_header.php'; ?>
    <section class="update-product">
        <h1 class="title">Update product</h1>
        <?php
        if (isset($_SESSION['success'])) {
            echo '
            <div class="message">
                <span>' . $_SESSION['success'] . '</span>
            </div>';
            unset($_SESSION['success']);
        }
        if (isset($_SESSION['error'])) {
            echo '
            <div class="message">
                <span>' . $_SESSION['error'] . '</span>
            </div>';
            unset($_SESSION['error']);
        }
        ?>

        <?php
        $update_id = $_GET['update'];
        $select_products = $conn->prepare("SELECT * FROM `products` WHERE id = ?");
        $select_products->execute([$update_id]);
        if ($select_products->rowCount() > 0) {
            while ($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)) {
        ?>
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="old_image" value="<?= $fetch_products['image']; ?>">
                    <input type="hidden" name="id" value="<?= $fetch_products['id']; ?>">
                    <img src="images/<?= $fetch_products['image']; ?>" alt="">
                    <span>Product name:</span>
                    <input type="text" name="name" placeholder="Enter product name" required class="box" value="<?= $fetch_products['name']; ?>">
                    <span>Product price:</span>
                    <input type="number" name="price" min="0" placeholder="Enter product price" required class="box" value="<?= $fetch_products['price']; ?>">
                    <span>Product category:</span>
                    <select name="category" class="box" required>
                        <option value="<?= $fetch_products['category']; ?>" selected><?= $fetch_products['category']; ?></option>
                        <option value="Vegetables">Vegetables</option>
                        <option value="Fruits">Fruits</option>
                        <option value="Meat">Meat</option>
                        <option value="Fish">Fish</option>
                    </select>
                    <span>Quantity:</span>
                    <input type="number" name="quantity" class="box" value="<?= $fetch_products['quantity']; ?>" required placeholder="Enter quantity">
                    <span>Manufacture date:</span>
                    <input type="date" name="mfg_date" class="box" value="<?= $fetch_products['mfg_date']; ?>" required placeholder="Enter date">
                    <span>Expiration date:</span>
                    <input type="date" name="exp_date" class="box" value="<?= $fetch_products['exp_date']; ?>" required placeholder="Enter date">
                    <span>About product:</span>
                    <textarea name="details" required placeholder="Enter product details" class="box" cols="30" rows="10"><?= $fetch_products['details']; ?></textarea>
                    <span>Product image:</span>
                    <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png">
                    <div class="flex-btn">
                        <input type="submit" class="btn" value="Update Product" name="update_product">
                        <a href="admin_products.php" class="option-btn">Go back</a>
                    </div>
                </form>
        <?php
            }
        } else {
            echo '<p class="empty">No products found!</p>';
        }
        ?>
    </section>
    <script src="js/script.js"></script>
</body>
</html>