<?php
@include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
    exit; // Add exit after redirection
}

if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
    $delete_cart_item->execute([$delete_id]);
    header('location:cart.php');
    exit; // Add exit after redirection
}

if (isset($_GET['delete_all'])) {
    $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
    $delete_cart_item->execute([$user_id]);
    header('location:cart.php');
    exit; // Add exit after redirection
}

if (isset($_POST['update_qty'])) {
    $cart_id = $_POST['cart_id'];
    $p_qty = $_POST['p_qty'];
    $p_qty = filter_var($p_qty, FILTER_SANITIZE_STRING);

    // Get the available quantity of the product
    $select_product = $conn->prepare("SELECT products.quantity AS available_quantity FROM `cart` INNER JOIN `products` ON cart.pid = products.id WHERE cart.id = ?");
    $select_product->execute([$cart_id]);
    $product = $select_product->fetch(PDO::FETCH_ASSOC);

    if ($product && $p_qty <= $product['available_quantity']) {
        $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
        $update_qty->execute([$p_qty, $cart_id]);
        $_SESSION['success'] = 'Cart quantity updated.';
    } else {
        $_SESSION['error'] = 'Requested quantity is not available .';
    }
    header('location:cart.php');
    exit; // Add exit after redirection
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <section class="shopping-cart">
        <h1 class="title">Products Added</h1>
        <?php
        if (isset($_SESSION['success'])) {
            echo '
         <div class="message success">
             <span>' . $_SESSION['success'] . '</span>
         </div>
         ';
            unset($_SESSION['success']);
        } ?>

        <?php
        if (isset($_SESSION['error'])) {
            echo '
   <div class="message error">
       <span>' . $_SESSION['error'] . '</span>
   </div>
   ';
            unset($_SESSION['error']);
        }
        ?>
        <div class="box-container">
            <?php
            $grand_total = 0;
            $select_cart = $conn->prepare("SELECT cart.id, cart.quantity, products.price, products.name, products.image, products.category, products.quantity AS available_quantity, products.mfg_date, products.exp_date, products.details FROM `cart` INNER JOIN `products` ON cart.pid = products.id WHERE cart.user_id = ?");
            $select_cart->execute([$user_id]);
            if ($select_cart->rowCount() > 0) {
                while ($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)) {
                    @$product_id = $fetch_cart['pid'];

                    $available_quantity = $fetch_cart['available_quantity'];
                    $category = $fetch_cart['category'];
                    $mfg_date = $fetch_cart['mfg_date'];
                    $exp_date = $fetch_cart['exp_date'];
                    $details = $fetch_cart['details'];
            ?>
                    <form action="" method="POST" class="box">
                        <a href="cart.php?delete=<?= $fetch_cart['id']; ?>" class="fas fa-times" onclick="return confirm('Delete this from cart?');"></a>
                        <div class="price">Rs.<span><?= $fetch_cart['price']; ?></span>/-</div>
                        <!-- <a href="view_page.php?pid=<?= $fetch_cart['id']; ?>" class="fas fa-eye"></a> -->
                        <img src="images/<?= $fetch_cart['image']; ?>" alt="" style="width: 225px; height: 200px;">
                        <div class="name">Name: <?= $fetch_cart['name']; ?></div>
                        <div class="category">Category: <?= $category; ?></div>
                        <div class="quantity">Quantity: <?= $fetch_cart['quantity']; ?> Kg</div> <!-- Display the selected quantity -->
                        <div class="mfg_date">Manufacture date: <?= $mfg_date; ?></div>
                        <div class="exp_date">Expiration date: <?= $exp_date; ?></div>
                        <!-- <div class="details">Details: <?= $details; ?></div> -->
                        <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>">
                        <div class="flex-btn">
                            <input type="number" min="1" value="<?= $fetch_cart['quantity']; ?>" class="qty" name="p_qty">
                            <input type="submit" value="Update" name="update_qty" class="option-btn">
                        </div>
                        <div class="sub-total">Sub Total: <span>Rs.<?= $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?>/-</span></div>
                    </form>
            <?php
                    $grand_total += $sub_total;
                }
            } else {
                echo '<p class="empty">Your cart is empty</p>';
            }
            ?>
        </div>
        <div class="cart-total">
            <p>Grand Total: <span>Rs.<?= $grand_total; ?>/-</span></p>
            <a href="shop.php" class="option-btn">Continue Shopping</a>
            <a href="cart.php?delete_all" class="delete-btn <?= ($grand_total > 1) ? '' : 'disabled'; ?>">Delete All</a>
            <a href="checkout.php" class="btn <?= ($grand_total > 1) ? '' : 'disabled'; ?>">Proceed to Checkout</a>
        </div>
    </section>
    <?php include 'footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>