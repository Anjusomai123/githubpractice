<?php
@include 'config.php';
session_start();
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    $user_id = '';
};

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <section class="about">
        <div class="row">
            <div class="box">
                <img src="images/about-img-1.png" alt="">
                <h3>why choose us?</h3>
                <p>Discover an extraordinary grocery shopping experience at Basnet Grocery Store. With unparalleled quality, diverse selection, exceptional service, competitive prices, convenient shopping, sustainability commitment and we are your top choice. Join us today for all your grocery needs.</p>
                <a href="contact.php" class="btn">contact us</a>
            </div>
            <div class="box">
                <img src="images/about-img-2.png" alt="">
                <h3>what we provide?</h3>
                <p>At our store we provide freshness and quality you can trust and extensive variety to suit every taste as well as exceptional customer service with competitive prices and convenient and efficient shopping experience with commitment to sustainability and active community involvement</p>
                <a href="shop.php" class="btn">our shop</a>
            </div>
        </div>
        </div>
    </section>

    <section class="reviews">
        <h1 class="title">clients reivews</h1>
        <div class="box-container">
            <div class="box">
                <img src="images/7309693.jpg" alt="">
                <p>"The freshness of their products is unbeatable! Every time I shop here, I'm amazed at the quality and taste. It's truly a delight to find a grocery store that prioritizes freshness."</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Manoj Pandey</h3>
            </div>
            <div class="box">
                <img src="images/7294793.jpg" alt="">
                <p>"The variety of products they offer is incredible. I can find everything I need, from local favorites to exotic ingredients. It's like exploring a culinary wonderland every time I visit."</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Gita Yadav</h3>
            </div>
            <div class="box">
                <img src="images/7309678.jpg" alt="">
                <p>"The customer service at this grocery store is outstanding. The staff is friendly, knowledgeable, and always willing to go the extra mile. They make you feel like a valued customer every time."</p>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Gaurav Sharma</h3>
            </div>
        </div>
    </section>
    <?php include 'footer.php'; ?>
    <script src="js/script.js"></script>
</body>

</html>