<?php
@include 'config.php';
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id)) {
    header('location:login.php');
};

if (isset($_POST['add_category'])) {
    $name = $_POST['name'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);

    $select_category = $conn->prepare("SELECT * FROM `category` WHERE name = ?");
    $select_category->execute([$name]);

    if ($select_category->rowCount() > 0) {
        $_SESSION['error'] = 'Category already exists!';
    } else {
        $insert_category = $conn->prepare("INSERT INTO `category` (name) VALUES (?)");
        $insert_category->execute([$name]);

        if ($insert_category) {
            $_SESSION['success'] = 'New category added!';
        }
    }
};

if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_category = $conn->prepare("DELETE FROM `category` WHERE id = ?");
    $delete_category->execute([$delete_id]);
    header('location:admin_category.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'admin_header.php'; ?>
    <section class="add-category">
        <h1 class="title">Add new category</h1>

        <?php
        if (isset($_SESSION['success'])) {
            echo '
      <div class="message">
         <span>' . $_SESSION['success'] . '</span>
         
      </div>
      ';
            unset($_SESSION['success']);
        }
        ?>
        <?php

        if (isset($_SESSION['error'])) {
            echo '
<div class="message">
 <span>' . $_SESSION['error'] . '</span>
</div>
';
            unset($_SESSION['error']);
        }
        ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="inputBox">
                <span>Category name:</span>
                <input type="text" name="name" class="box" required placeholder="Enter category name">
            </div>
            <input type="submit" class="btn" value="Add Category" name="add_category">
        </form>
    </section>

    <section class="show-categories">
        <h1 class="title">Categories added</h1>
        <div class="box-container">
            <?php
            $show_categories = $conn->prepare("SELECT * FROM `category`");
            $show_categories->execute();
            if ($show_categories->rowCount() > 0) {
                while ($fetch_categories = $show_categories->fetch(PDO::FETCH_ASSOC)) {
            ?>
                    <div class="box">
                        <div class="name">Name: <?= $fetch_categories['name']; ?></div>
                        <div class="flex-btn">
                            <a href="#" class="option-btn">Update</a>
                            <a href="admin_category.php?delete=<?= $fetch_categories['id']; ?>" class="delete-btn" onclick="return confirm('Delete this category?');">Delete</a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p class="empty">No categories added yet!</p>';
            }
            ?>
        </div>
    </section>
    <script src="js/script.js"></script>
</body>

</html>