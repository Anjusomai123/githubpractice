<?php
@include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
};

if (isset($_POST['order'])) {
    $status = 1;
    $name = $_POST['name'];
    // Validate Name
    if (empty($name)) {
        $errors['name'] = 'Please enter your name';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $errors['name'] = 'Name should only contain letters and spaces';
        $status = 0;
    } elseif (strlen($name) < 3) {
        $errors['name'] = 'Name should be at least 3 characters long';
        $status = 0;
    }


    $number = $_POST['number'];
    // Validate Number
    if (empty($number)) {
        $errors['number'] = 'Please enter your number';
        $status = 0;
    } elseif (!preg_match("/^[0-9]{10}$/", $number)) {
        $errors['number'] = 'Number should be a 10-digit value';
        $status = 0;
    }


    $email = $_POST['email'];
    // Validate Email
    if (empty($email)) {
        $errors['email'] = 'Please enter your email';
        $status = 0;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
        $status = 0;
    }

    $addressLine1 = $_POST['flat'];
    // Validate Address Line 01
    if (empty($addressLine1)) {
        $errors['flat'] = 'Please enter tole name';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $addressLine1)) {
        $errors['flat'] = 'Tole nameshould only contain letters and spaces';
        $status = 0;
    }

    $addressLine2 = $_POST['street'];
    // Validate Address Line 02
    if (empty($addressLine2)) {
        $errors['street'] = 'Please enter street name';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $addressLine2)) {
        $errors['street'] = 'Street name should only contain letters and spaces';
        $status = 0;
    }


    $city = $_POST['city'];
    // Validate City
    if (empty($city)) {
        $errors['city'] = 'Please enter city';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $city)) {
        $errors['city'] = 'City should only contain letters and spaces';
        $status = 0;
    }

    $province = $_POST['province'];
    // Validate Province
    if (empty($province)) {
        $errors['province'] = 'Please enter province';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $province)) {
        $errors['province'] = 'Province should only contain letters and spaces';
        $status = 0;
    }

    $country = $_POST['country'];
    // Validate Country
    if (empty($country)) {
        $errors['country'] = 'Please enter country';
        $status = 0;
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $country)) {
        $errors['country'] = 'Country should only contain letters and spaces';
        $status = 0;
    }


    $zipCode = $_POST['zipCode'];
    // Validate Zip Code
    if (empty($zipCode)) {
        $errors['zipCode'] = 'Please enter zip code';
        $status = 0;
    } elseif (!preg_match("/^[0-9]+$/", $zipCode)) {
        $errors['zipCode'] = 'Zip code should only contain numbers';
        $status = 0;
    }

    // for payment method
    $method = $_POST['method'];
    // for address
    $address = 'Tole: ' . $_POST['flat']  .  '  -Street :  ' .  $_POST['street']  .  '  -City: '  . $_POST['city'] .  '  -Province: ' .  $_POST['province']  . '  -Country: '  . $_POST['country'] . '  -ZIP Code: ' . $_POST['zipCode'];
    $placed_on = date('d-M-Y');

    $cart_total = 0;
    $cart_products = [];

    $cart_query = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
    $cart_query->execute([$user_id]);

    if ($cart_query->rowCount() > 0) {
        while ($cart_item = $cart_query->fetch(PDO::FETCH_ASSOC)) {
            $cart_products[] = $cart_item;
            $sub_total = ($cart_item['price'] * $cart_item['quantity']);
            $cart_total += $sub_total;
        }
    }

    $product_strings = [];
    foreach ($cart_products as $cart_item) {
        @$product_strings[] = $cart_item['name'] . ' (' . $cart_item['quantity'] . ' ' . $cart_item['quantity_unit'] . ' kg' . ')';
    }
    $total_products = implode(', ', $product_strings);

    $order_query = $conn->prepare("SELECT * FROM `orders` WHERE name = ? AND number = ? AND email = ? AND method = ? AND address = ? AND total_products = ? AND total_price = ?");
    $order_query->execute([$name, $number, $email, $method, $address, $total_products, $cart_total]);

    if ($cart_total == 0) {
        $_SESSION['error'] = 'Your cart is empty';
        $status = 0;
    } elseif (empty($zipCode)) {
        $_SESSION['error'] = 'Provide your information';
        $status = 0;
    } elseif ($order_query->rowCount() > 0) {
        $_SESSION['error'] = 'Order placed already!';
        $status = 0;
    } else {
        if ($status == 1) {
            // Insert order into orders table
            $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price, placed_on) VALUES(?,?,?,?,?,?,?,?,?)");
            $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $cart_total, $placed_on]);

            // Loop through cart items and update product quantities
            foreach ($cart_products as $cart_item) {
                $product_id = $cart_item['pid'];
                $quantity_purchased = $cart_item['quantity'];
                updateProductQuantity($product_id, $quantity_purchased);
            }

            // Delete cart items
            $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
            $delete_cart->execute([$user_id]);
            $_SESSION['success'] = 'Order placed successfully!';
        }
    }
}

function updateProductQuantity($product_id, $quantity_purchased)
{
    // Include database connection here
    include 'config.php';

    // Fetch current product quantity
    $select_product = $conn->prepare("SELECT quantity FROM `products` WHERE id = ?");
    $select_product->execute([$product_id]);
    $fetch_product = $select_product->fetch(PDO::FETCH_ASSOC);
    $current_quantity = $fetch_product['quantity'];

    // Calculate new quantity
    $new_quantity = $current_quantity - $quantity_purchased;

    // Update product quantity in the database
    $update_product = $conn->prepare("UPDATE `products` SET quantity = ? WHERE id = ?");
    $update_product->execute([$new_quantity, $product_id]);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <!-- Font style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom css file link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header.php'; ?>
    <section class="display-orders">

        <?php
        $cart_grand_total = 0;
        $select_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
        $select_cart_items->execute([$user_id]);
        if ($select_cart_items->rowCount() > 0) {
            while ($fetch_cart_items = $select_cart_items->fetch(PDO::FETCH_ASSOC)) {
                $cart_total_price = ($fetch_cart_items['price'] * $fetch_cart_items['quantity']);
                $cart_grand_total += $cart_total_price;
        ?>
                <p> <?= $fetch_cart_items['name']; ?><span>(<?= 'Rs' . $fetch_cart_items['price'] . '/- x ' . $fetch_cart_items['quantity']; ?>)</span> </p>
        <?php
            }
        } else {
            echo '<p class="empty">Your cart is empty!</p>';
        }
        ?>
        <div class="grand-total">Grand total : <span>Rs <?= $cart_grand_total; ?>/-</span></div>
    </section>

    <section class="checkout-orders">
        <!-- message -->

        <?php if (isset($_SESSION['success'])) : ?>
            <div class="message success">
                <span><?php echo $_SESSION['success']; ?></span>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])) : ?>
            <div class="message error">
                <span><?php echo $_SESSION['error']; ?></span>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>


        <form action="" method="POST">
            <h3>Place your order</h3>
            <div class="flex">

                <div class="inputBox">
                    <span>Your Name :</span>
                    <input type="text" name="name" class="box" placeholder="Enter your name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>">
                    <?php if (isset($errors['name'])) : ?>
                        <div class="error-message"><?php echo $errors['name']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Your Number :</span>
                    <input type="number" name="number" min="0" class="box" placeholder="Enter your number" value="<?php echo isset($number) ? htmlspecialchars($number) : ''; ?>">
                    <?php if (isset($errors['number'])) : ?>
                        <div class="error-message"><?php echo $errors['number']; ?></div>
                    <?php endif; ?>

                </div>

                <div class="inputBox">
                    <span>Your Email :</span>
                    <input type="email" name="email" class="box" placeholder="Enter your email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                    <?php if (isset($errors['email'])) : ?>
                        <div class="error-message"><?php echo $errors['email']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Payment method :</span>
                    <select name="method" class="box">
                        <option value="Cash on delivery">Cash on delivery</option>
                        <option value="Credit card">Credit card</option>
                        <option value="E-Sewa">E-Sewa</option>
                        <option value="Khalti">Khalti</option>
                        <option value="IME Pay">IME pay</option>
                    </select>
                </div>

                <div class="inputBox">
                    <span>Tole name :</span>
                    <input type="text" name="flat" class="box" placeholder="e.g. Shantinagar" value="<?php echo isset($addressLine1) ? htmlspecialchars($addressLine1) : ''; ?>">
                    <?php if (isset($errors['flat'])) : ?>
                        <div class="error-message"><?php echo $errors['flat']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Street name :</span>
                    <input type="text" name="street" class="box" placeholder="e.g. Pipira street" value="<?php echo isset($addressLine2) ? htmlspecialchars($addressLine2) : ''; ?>">
                    <?php if (isset($errors['street'])) : ?>
                        <div class="error-message"><?php echo $errors['street']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>City :</span>
                    <input type="text" name="city" class="box" placeholder="e.g. Surkhet" value="<?php echo isset($city) ? htmlspecialchars($city) : ''; ?>">
                    <?php if (isset($errors['city'])) : ?>
                        <div class="error-message"><?php echo $errors['city']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Province :</span>
                    <input type="text" name="province" class="box" placeholder="e.g. Karnali" value="<?php echo isset($province) ? htmlspecialchars($province) : ''; ?>">
                    <?php if (isset($errors['province'])) : ?>
                        <div class="error-message"><?php echo $errors['province']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Country :</span>
                    <input type="text" name="country" class="box" placeholder="e.g. Nepal" value="<?php echo isset($country) ? htmlspecialchars($country) : ''; ?>">
                    <?php if (isset($errors['country'])) : ?>
                        <div class="error-message"><?php echo $errors['country']; ?></div>
                    <?php endif; ?>
                </div>

                <div class="inputBox">
                    <span>Zip code :</span>
                    <input type="number" name="zipCode" class="box" placeholder="e.g. 21700" value="<?php echo isset($zipCode) ? htmlspecialchars($zipCode) : ''; ?>">
                    <?php if (isset($errors['zipCode'])) : ?>
                        <div class="error-message"><?php echo $errors['zipCode']; ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <input type="submit" name="order" class="btn <?= ($cart_grand_total > 1) ? '' : 'disabled'; ?>" value="place order">
        </form>
    </section>
    <?php include 'footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>