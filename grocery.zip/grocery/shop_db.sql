-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2023 at 02:27 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `mfg_date` date NOT NULL,
  `exp_date` date NOT NULL,
  `details` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(20, 88, 'Man', 'ram1@gmail.com', '6767766662', 'kjvbkjv'),
(22, 88, 'Ramnarayan', 'ram1@gmail.com', '9876543217', 'jbkjb'),
(23, 114, 'Manish', 'manish1@gmail.com', '8888888888', 'jbdjsbqj');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(124, 123, 'Manish Basnet', '8888888888', 'manish1@gmail.com', 'E-Sewa', 'Tole: Pipira  -Street :  Pipira street  -City: Surkhet  -Province: Karnali  -Country: Nepal  -ZIP Code: 3000', 'Goat meat (1  kg), Green grapes (1  kg), Chicken meat (1  kg), Watermelon (1  kg)', 2250, '24-Aug-2023', 'Completed'),
(125, 123, 'kazii', '8888888888', 'manish1@gmail.com', 'Khalti', 'Tole: jbsekjfbsdkja  -Street :  lbwdkj  -City: lbdw  -Province: hrgtdhfjghdif  -Country: Nepal  -ZIP Code: 1111', 'Watermelon (1  kg)', 500, '25-Aug-2023', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `mfg_date` date NOT NULL,
  `exp_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `details`, `price`, `image`, `quantity`, `mfg_date`, `exp_date`) VALUES
(26, 'Banana', 'Fruits', 'Bananaaaaaaaaa', 200, 'banana.png', 300, '2023-01-01', '2023-10-10'),
(27, 'Goat meat', 'Meat', 'Meat', 1000, 'beaf steak.png', 99, '2023-01-01', '2023-10-01'),
(28, 'Green grapes', 'Fruits', 'Grapes.', 300, 'green grapes.png', 1199, '2023-01-01', '2023-10-10'),
(29, 'Capsicum', 'Vegetables', 'Capsicum', 200, 'capsicum.png', 50, '2023-01-02', '2023-10-01'),
(30, 'Watermelon', 'Fruits', 'Watermelon', 500, 'watermelon.png', 97, '2023-01-01', '2023-10-01'),
(31, 'Carrot', 'Fruits', 'carrotttttttttt', 200, 'carrot.png', 100, '2023-01-01', '2023-10-01'),
(33, 'Orange', 'Fruits', 'Orangeeeeee', 200, 'orange.png', 200, '2023-01-01', '2024-10-01'),
(34, 'Chicken meat', 'Meat', ' High-quality protein.', 450, 'chicken.png', 48, '2023-05-01', '2023-08-20'),
(38, 'Basmati rice', 'Kitchen Items', 'Basmati rice.', 400, 'Rice_AdobeStock_64819529_E-removebg-preview.png', 200, '2022-01-01', '2025-01-01'),
(40, 'Blue Grapes', 'Fruits', 'Blue Grapes.', 300, 'blue grapes.png', 200, '2023-01-01', '2023-10-10'),
(41, 'Apple', 'Fruits', 'Apple..', 200, 'apple.png', 150, '2023-01-01', '2023-10-01'),
(42, 'Broccouli', 'Vegetables', 'Coliiii', 50, 'broccoli.png', 100, '2023-01-30', '2023-10-30'),
(43, 'Cabbage', 'Vegetables', 'Cabbage', 100, 'cabbage.png', 200, '2023-01-05', '2023-10-23'),
(45, 'Pork meat', 'Meat', 'Pork meat', 500, 'cat-2.png', 100, '2023-01-01', '2023-10-02'),
(46, 'Chicken leg', 'Meat', 'Chicken leg', 200, 'chicken leg pieces.png', 50, '2023-01-01', '2023-10-02'),
(47, 'Litchi', 'Fruits', 'Litchiii', 300, 'lichi.png', 100, '2023-01-01', '2024-01-01'),
(48, 'Red chilly ', 'Vegetables', 'Chilly', 100, 'red papper.png', 100, '2023-01-01', '2023-10-10'),
(49, 'Tomatto', 'Vegetables', 'Tomatto', 200, 'tomato.png', 100, '2023-02-01', '2024-01-01'),
(50, 'Strawberry', 'Fruits', 'Strawberry', 200, 'strawberry.png', 100, '2023-01-01', '2024-01-01'),
(51, 'Fish', 'Meat', 'Fishhh', 2000, 'semon fish.png', 400, '2023-01-01', '2023-01-01'),
(52, 'Red onion', 'Vegetables', 'Onionn', 300, 'Red-Onion-PNG-HD.png', 100, '2023-01-01', '2024-01-01'),
(53, 'Spinach-leaf', 'Vegetables', 'spinach-leaf...', 50, 'vegetable-salad-spinach-leaf-hd-png-11653148602v7y8oymh2y (1).png', 100, '2023-01-01', '2024-01-01'),
(54, 'Salt', 'Kitchen Items', 'Salt', 25, '14pran_salt_750x750p-min.png', 200, '2022-01-01', '2024-01-01'),
(55, 'Egg plant', 'Vegetables', 'Egg plant...', 50, 'images.jfif', 100, '2023-01-01', '2024-01-01'),
(56, 'Potato', 'Vegetables', 'Potato..', 70, 'Potato-10-2.png', 200, '2023-01-01', '2024-01-01'),
(57, 'Cucumber', 'Vegetables', 'Cucumber..', 45, '11-2-cucumber-png-file.png', 200, '2023-01-01', '2023-01-01'),
(58, 'Radish', 'Vegetables', 'Radish...', 40, 'Raddish-PNG-Photos.png', 100, '2023-01-01', '2024-01-01'),
(59, 'Cumin', 'Kitchen Items', 'Cumin...', 1000, 'images (1).jfif', 100, '2023-01-01', '2024-01-01'),
(60, 'Oil', 'Kitchen Items', 'Oil', 1200, 'images (2).jfif', 1000, '2022-01-01', '2024-02-02'),
(61, 'Turmeric', 'Kitchen Items', 'turmeric', 500, 'images (3).jfif', 100, '2023-01-01', '2024-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`, `image`) VALUES
(122, 'Jems Grocery Store', 'jems1@gmail.com', 'Jems1@', 'admin', '836.jpg'),
(123, 'Manish Basnet', 'manish1@gmail.com', 'Manish1@', 'user', '60111.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `details` varchar(500) NOT NULL,
  `mfg_date` date NOT NULL,
  `exp_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
